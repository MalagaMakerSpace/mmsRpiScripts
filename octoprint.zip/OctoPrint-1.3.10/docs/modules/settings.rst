.. _sec-modules-settings:

octoprint.settings
------------------

.. automodule:: octoprint.settings
