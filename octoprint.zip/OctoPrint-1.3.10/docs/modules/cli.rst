.. _sec-modules-cli:

octoprint.cli
-------------

.. automodule:: octoprint.cli
   :members:

.. _sec-modules-cli-dev:

octoprint.cli.dev
-----------------

.. automodule:: octoprint.cli.dev
   :members:

.. _sec-modules-cli-plugins:

octoprint.cli.plugins
---------------------

.. automodule:: octoprint.cli.plugins
   :members:

.. _sec-modules-cli-server:

octoprint.cli.server
--------------------

.. automodule:: octoprint.cli.server
   :members:
