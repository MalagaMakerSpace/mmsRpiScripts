.. _sec-modules-printer:

octoprint.printer
-----------------

.. automodule:: octoprint.printer

.. _sec-modules-printer-profile:

octoprint.printer.profile
-------------------------

.. automodule:: octoprint.printer.profile
