.. _section-features:

********
Features
********

.. note::

   This feature list is not exhaustive. This part of OctoPrint's documentation is sadly far from finished still.

.. toctree::
   :maxdepth: 2

   accesscontrol.rst
   custom_controls.rst
   gcode_scripts.rst
   action_commands.rst
   atcommands.rst
   plugins.rst
   safemode.rst
