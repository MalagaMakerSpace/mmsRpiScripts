.. _sec-bundledplugins:

###############
Bundled Plugins
###############

.. toctree::
   :maxdepth: 2

   action_command_prompt.rst
   announcements.rst
   appkeys.rst
   backup.rst
   cura.rst
   discovery.rst
   forcelogin.rst
   logging.rst
   pluginmanager.rst
   printer_safety_check.rst
   softwareupdate.rst
