#!/usr/bin/env python2
print("throttled=0x50005")
