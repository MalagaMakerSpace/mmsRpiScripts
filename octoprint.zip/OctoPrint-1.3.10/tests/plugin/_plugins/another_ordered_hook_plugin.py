def callback(*args, **kwargs):
	pass

__plugin_hooks__ = {
	"some.ordered.callback": (callback, 100)
}
