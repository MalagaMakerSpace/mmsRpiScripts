# Supporters 

Development of this version of OctoPrint wouldn't have been possible without
[the financial support by the community](https://octoprint.org/support-octoprint/) -
thanks to everyone who contributed!

## Patreon Patrons

  * Andre Bubel
  * Andrew Moorby
  * Arnljot Arntsen
  * Boris Hussein
  * Brad Jackson
  * Christian Petropolis
  * Christian Wolf
  * COLLE+McVOY
  * D Brian Kimmel
  * DeltaMaker 3D Printers
  * E3D BigBox
  * Eric Betts
  * Eric Slape
  * Ernesto Martinez
  * Frank Sander
  * George Robles
  * Jared Go
  * Jeff Renfer
  * Jefferson Hunt
  * Jeremiah Avery
  * Joseph Payne
  * Josh Daniels
  * Joshua Wills
  * Justin Kaufman
  * Kaile Riser
  * Kale Stedman
  * Kazuhiro Ogura
  * LA 3D Printer Repair
  * Lewis Newby
  * LulzBot®
  * Makespace Madrid
  * Mark Walker
  * Michael Aumock
  * Miles Flavel
  * Mosaic Manufacturing
  * Patrick McGinnis
  * Prof Yuh Wen Chen
  * Randy C. Will
  * Robert Gusek
  * Roger Strolz
  * Samer Najia
  * Simon Hallam
  * Stefan Krister
  * Sven Mueller
  * Thomas Hatley
  * Timothy D Hoogland
  * Trent Shumay

and 1446 more wonderful people pledging on the [Patreon campaign](https://patreon.com/foosel)!