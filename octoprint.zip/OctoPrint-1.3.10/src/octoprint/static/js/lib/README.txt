Readme
======

Heads-up regarding the following dependencies:

  lodash.js
    Breaking changes in v4.x+, needs migration before
    update from 3.x is possible
